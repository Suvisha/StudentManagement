import React from 'react';

class DeleteStudent extends React.Component
{
    render()
    {
        return(
                <div>
                      DeleteStudent
                </div>
        );
    }
}
export default DeleteStudent;