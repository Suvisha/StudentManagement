import React from 'react';

class EditStudent extends React.Component
{
    render()
    {
        return(
                <div>
                      EditStudent
                </div>
        );
    }
}
export default EditStudent;